# Module Mapping
Authentication, Catalog, CRM, Sales, Purchase, Inventory, Finance, Reports.
