# CoboPOS Architecture
Enterprise Clean Architecture blueprint.
